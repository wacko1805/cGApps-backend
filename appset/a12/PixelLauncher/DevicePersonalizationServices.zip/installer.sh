#!/sbin/sh
configValue="$1"
nikgapps_config_file_name="$2"

find_Install_partition() {
  addToLog "- default_partition=$default_partition"
  install_partition="/system/product"
  case $default_partition in
    "system_ext")
      [ -z "$system_ext" ] && system_ext=$product
      # if partition doesn't exist or it is not mounted as rw, moving to secondary partition
      [ -z "$system_ext" ] && system_ext=$system
      install_partition=$system_ext
    ;;
    "product")
      # if partition doesn't exist or it is not mounted as rw, moving to secondary partition
      [ -z "$product" ] && product=$system
      install_partition=$product
    ;;
  esac
  if [ -f "$nikgapps_config_file_name" ]; then
    case "$install_partition_val" in
      "default") addToLog "- InstallPartition is default" ;;
      "system") install_partition=$system ;;
      "product") install_partition=$product ;;
      "system_ext") install_partition=$system_ext ;;
      "data") install_partition="/data/extra" ;;
      /*) install_partition=$install_partition_val ;;
    esac
    addToLog "- InstallPartition = $install_partition"
  else
    addToLog "- nikgapps.config file doesn't exist!"
  fi
  case "$install_partition" in
    *"/product") product_prefix="product/" ;;
    *"/system_ext") product_prefix="system_ext/" ;;
    *) product_prefix="" ;;
  esac
}

make_dir() {
  addToLog "- Creating Directory: $install_partition/$1"
  mkdir -p "$install_partition/$1"
  set_perm 1000 1000 0755 "$install_partition/$1"
}

# Initialize the variables
default_partition="product"
clean_flash_only="false"
find_Install_partition
title="MatchmakerPrebuiltPixel4"
package_title="DevicePersonalizationServices"
pkg_size="116667"
package_name="com.google.android.as"
packagePath=installDevicePersonalizationServicesFiles
deleteFilesPath=deleteDevicePersonalizationServicesFiles
deleteFilesFromRomPath=deleteDevicePersonalizationServicesFromRomFiles

remove_aosp_apps_from_rom="
"

remove_gapps_from_rom="
DevicePersonalizationPrebuiltPixel4
"

file_list="
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libsense.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libim2intent_jni.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libsimple_itracker_jni.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libcpuutils.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libtask_text_jni.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libdeepclu_jni_aiai.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libparticle-extractor_jni.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libdps_soda_pixel_s_jni.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/liblang_id_jni_model_less_native.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libtrainingfeatureprocessor_jni_gmscore.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libaiai_vkp.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libtensorflowlite_jni.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libbarhopper_v2.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libspelling_checker_jni.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libtextclassifier3_jni_aiai.so
___priv-app___MatchmakerPrebuiltPixel4___lib___arm64/libclient_android_jni.so
___etc___permissions/com.google.android.as.xml
___priv-app___MatchmakerPrebuiltPixel4/MatchmakerPrebuiltPixel4.apk
"

remove_existing_package() {
   # remove the existing folder for clean install of DevicePersonalizationServices
   delete_package "MatchmakerPrebuiltPixel4"
}

remove_aosp_apps() {
   # Delete the folders that we want to remove with installing DevicePersonalizationServices
   for i in $remove_aosp_apps_from_rom; do
       RemoveAospAppsFromRom "$i"
   done
}

remove_gapps_from_rom() {
   # Delete the folders that we want to remove with installing on Rom with Gapps
   for i in $remove_gapps_from_rom; do
       RemoveFromRomWithGapps "$i"
   done
}

install_package() {
   remove_existing_package
   remove_aosp_apps
   remove_gapps_from_rom
   # Create folders and set the permissions
   make_dir "priv-app/MatchmakerPrebuiltPixel4"
   make_dir "priv-app/MatchmakerPrebuiltPixel4/lib"
   make_dir "priv-app/MatchmakerPrebuiltPixel4/lib/arm64"
   make_dir "etc/permissions"

   # Copy the files and set the permissions
   for i in $file_list; do
       install_file "$i"
   done
   install_file "___etc___permissions/DevicePersonalizationServices.prop"

   chmod 755 "$COMMONDIR/addon";
   . $COMMONDIR/addon "$OFD" "DevicePersonalizationServices" "$TMPDIR/addon/$packagePath" "$TMPDIR/addon/$deleteFilesPath" "" "$TMPDIR/addon/$deleteFilesFromRomPath"
   copy_file "$NikGappsAddonDir/DevicePersonalizationServices.sh" "$logDir/addonscripts/DevicePersonalizationServices.sh"
   copy_file "$TMPDIR/addon/$packagePath" "$logDir/addonfiles/$packagePath.addon"
   rm -rf "$TMPDIR/addon/$packagePath"
   copy_file "$TMPDIR/addon/$deleteFilesPath" "$logDir/addonfiles/$deleteFilesPath.addon"
   copy_file "$TMPDIR/addon/$deleteFilesFromRomPath" "$logDir/addonfiles/$deleteFilesFromRomPath.addon"
   rm -rf "$TMPDIR/addon/$deleteFilesPath"
   rm -rf "$TMPDIR/addon/$deleteFilesFromRomPath"
}

uninstall_package() {
   # Remove the files when we're uninstalling NiKGapps
   for i in $file_list; do
       uninstall_file "$i"
   done
}

find_install_mode

