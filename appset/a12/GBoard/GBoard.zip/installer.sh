#!/sbin/sh
configValue="$1"
nikgapps_config_file_name="$2"

find_Install_partition() {
  addToLog "- default_partition=$default_partition"
  install_partition="/system/product"
  case $default_partition in
    "system_ext")
      [ -z "$system_ext" ] && system_ext=$product
      # if partition doesn't exist or it is not mounted as rw, moving to secondary partition
      [ -z "$system_ext" ] && system_ext=$system
      install_partition=$system_ext
    ;;
    "product")
      # if partition doesn't exist or it is not mounted as rw, moving to secondary partition
      [ -z "$product" ] && product=$system
      install_partition=$product
    ;;
  esac
  if [ -f "$nikgapps_config_file_name" ]; then
    case "$install_partition_val" in
      "default") addToLog "- InstallPartition is default" ;;
      "system") install_partition=$system ;;
      "product") install_partition=$product ;;
      "system_ext") install_partition=$system_ext ;;
      "data") install_partition="/data/extra" ;;
      /*) install_partition=$install_partition_val ;;
    esac
    addToLog "- InstallPartition = $install_partition"
  else
    addToLog "- nikgapps.config file doesn't exist!"
  fi
  case "$install_partition" in
    *"/product") product_prefix="product/" ;;
    *"/system_ext") product_prefix="system_ext/" ;;
    *) product_prefix="" ;;
  esac
}

make_dir() {
  addToLog "- Creating Directory: $install_partition/$1"
  mkdir -p "$install_partition/$1"
  set_perm 1000 1000 0755 "$install_partition/$1"
}

# Initialize the variables
default_partition="product"
clean_flash_only="true"
find_Install_partition
title="LatinIMEGooglePrebuilt"
package_title="GBoard"
pkg_size="146732"
package_name="com.google.android.inputmethod.latin"
packagePath=installGBoardFiles
deleteFilesPath=deleteGBoardFiles
deleteFilesFromRomPath=deleteGBoardFromRomFiles

remove_aosp_apps_from_rom="
LatinIME
"

remove_gapps_from_rom="
"

file_list="
___usr___srec___en-US/g2p.data
___usr___srec___en-US/contacts.abnf
___usr___srec___en-US/CONTACT_NAME.syms
___usr___srec___en-US/hmmlist
___usr___srec___en-US/compile_grammar.config
___usr___srec___en-US/g2p_phonemes.syms
___usr___srec___en-US/am_phonemes.syms
___usr___srec___en-US/endpointer_model.mmap
___usr___srec___en-US/wordlist.syms
___usr___srec___en-US/endpointer_voicesearch.config
___usr___srec___en-US/word_confidence_classifier
___usr___srec___en-US/dictation.config
___usr___srec___en-US/phonelist
___usr___srec___en-US/lexicon.U.fst
___usr___srec___en-US/offensive_word_normalizer.mfar
___usr___srec___en-US/endpointer_model
___usr___srec___en-US/APP_NAME.syms
___usr___srec___en-US/portable_lstm
___usr___srec___en-US/TERSE_LSTM_LM.lstm_lm.main_model.uint8.data
___usr___srec___en-US/TERSE_LSTM_LM.lstm_lm.syms
___usr___srec___en-US/endpointer_dictation.config
___usr___srec___en-US/APP_NAME.fst
___usr___srec___en-US/grammar.config
___usr___srec___en-US/input_mean_std_dev
___usr___srec___en-US/config.pumpkin
___usr___srec___en-US/voice_actions_compiler.config
___usr___srec___en-US/en-US_read-items_SearchMessageAction-Prompted-Skip_TWIDDLER_FST.fst
___usr___srec___en-US/g2p_fst
___usr___srec___en-US/en-US_monastery_contact-disambig-static_TWIDDLER_FST.fst
___usr___srec___en-US/en-US_confirmation_confirmation-cancellation_TWIDDLER_FST.fst
___usr___srec___en-US/commands.abnf
___usr___srec___en-US/en-US_app-actions_prompted-app-name_TWIDDLER_FST.fst
___usr___srec___en-US/embedded_class_denorm.mfar
___usr___srec___en-US/magic_mic.config
___usr___srec___en-US/portable_meanstddev
___usr___srec___en-US/en-US_read-items_SearchMessageAction-Prompted-Read_TWIDDLER_FST.fst
___usr___srec___en-US/c_fst
___usr___srec___en-US/SONG_NAME.syms
___usr___srec___en-US/CONTACT.transform.mfar
___usr___srec___en-US/CLG.prewalk.fst
___usr___srec___en-US/dnn
___usr___srec___en-US/en-US_monastery_GenericAction-Prompted-ContactName_TWIDDLER_FST.fst
___usr___srec___en-US/semantics.pumpkin
___usr___srec___en-US/en-US_media-actions_music-service-controllable_TWIDDLER_FST.fst
___usr___srec___en-US/CONTACT_NAME.fst
___usr___srec___en-US/verbalizer_terse.mfar
___usr___srec___en-US/TERSE_LSTM_LM.lstm_lm.self_normalized_model.uint8.data
___usr___srec___en-US/prons_exception_dictionary_file.txt
___usr___srec___en-US/en-US_gmm-actions_gmm-nav-actions_TWIDDLER_FST.fst
___usr___srec___en-US/embedded_normalizer.mfar
___usr___srec___en-US/norm_fst
___usr___srec___en-US/g2p_graphemes.syms
___usr___srec___en-US/offline_action_data.pb
___usr___srec___en-US/dict
___usr___srec___en-US/SONG_NAME.fst
___usr___srec___en-US/metadata
___usr___srec___en-US/en-US_time-actions_time-context_TWIDDLER_FST.fst
___usr___srec___en-US/hmm_symbols
___usr___srec___en-US/monastery_config.pumpkin
___usr___srec___en-US/lstm_model.uint8.data
___usr___srec___en-US/en-US_calendar-actions_AddCalendarEvent-Prompted-FieldToChange_TWIDDLER_FST.fst
___usr___srec___en-US/rescoring.fst.compact
___usr___srec___en-US/pumpkin.mmap
___usr___srec___en-US/voice_actions.config
___usr___srec___en-US/ep_portable_model.uint8.mmap
___usr___srec___en-US/ep_portable_mean_stddev
___lib/libjni_latinimegoogle.so
___lib64/libjni_latinimegoogle.so
___app___LatinIMEGooglePrebuilt/LatinIMEGooglePrebuilt.apk
___usr___share___ime___google___d3_lms/ko_2018030706.zip
___usr___share___ime___google___d3_lms/zh_CN_2018030706.zip
___usr___share___ime___google___d3_lms/mozc.data
"

remove_existing_package() {
   # remove the existing folder for clean install of GBoard
   delete_package "LatinIMEGooglePrebuilt"
}

remove_aosp_apps() {
   # Delete the folders that we want to remove with installing GBoard
   for i in $remove_aosp_apps_from_rom; do
       RemoveAospAppsFromRom "$i"
   done
}

remove_gapps_from_rom() {
   # Delete the folders that we want to remove with installing on Rom with Gapps
   for i in $remove_gapps_from_rom; do
       RemoveFromRomWithGapps "$i"
   done
}

install_package() {
   remove_existing_package
   remove_aosp_apps
   remove_gapps_from_rom
   # Create folders and set the permissions
   make_dir "usr"
   make_dir "usr/srec"
   make_dir "usr/srec/en-US"
   make_dir "lib"
   make_dir "lib64"
   make_dir "app"
   make_dir "app/LatinIMEGooglePrebuilt"
   make_dir "usr/share"
   make_dir "usr/share/ime"
   make_dir "usr/share/ime/google"
   make_dir "usr/share/ime/google/d3_lms"

   # Copy the files and set the permissions
   for i in $file_list; do
       install_file "$i"
   done
   install_file "___etc___permissions/GBoard.prop"


   set_prop "ro.com.google.ime.bs_theme" "true" "$install_partition/build.prop"
   set_prop "ro.com.google.ime.theme_id" "5" "$install_partition/build.prop"
   set_prop "ro.com.google.ime.system_lm_dir" "$install_partition/usr/share/ime/google/d3_lms" "$install_partition/build.prop"
        
   chmod 755 "$COMMONDIR/addon";
   . $COMMONDIR/addon "$OFD" "GBoard" "$TMPDIR/addon/$packagePath" "$TMPDIR/addon/$deleteFilesPath" "" "$TMPDIR/addon/$deleteFilesFromRomPath"
   copy_file "$NikGappsAddonDir/GBoard.sh" "$logDir/addonscripts/GBoard.sh"
   copy_file "$TMPDIR/addon/$packagePath" "$logDir/addonfiles/$packagePath.addon"
   rm -rf "$TMPDIR/addon/$packagePath"
   copy_file "$TMPDIR/addon/$deleteFilesPath" "$logDir/addonfiles/$deleteFilesPath.addon"
   copy_file "$TMPDIR/addon/$deleteFilesFromRomPath" "$logDir/addonfiles/$deleteFilesFromRomPath.addon"
   rm -rf "$TMPDIR/addon/$deleteFilesPath"
   rm -rf "$TMPDIR/addon/$deleteFilesFromRomPath"
}

uninstall_package() {
   # Remove the files when we're uninstalling NiKGapps
   for i in $file_list; do
       uninstall_file "$i"
   done
}

find_install_mode

