#!/sbin/sh
configValue="$1"
nikgapps_config_file_name="$2"

find_Install_partition() {
  addToLog "- default_partition=$default_partition"
  install_partition="/system/product"
  case $default_partition in
    "system_ext")
      [ -z "$system_ext" ] && system_ext=$product
      # if partition doesn't exist or it is not mounted as rw, moving to secondary partition
      [ -z "$system_ext" ] && system_ext=$system
      install_partition=$system_ext
    ;;
    "product")
      # if partition doesn't exist or it is not mounted as rw, moving to secondary partition
      [ -z "$product" ] && product=$system
      install_partition=$product
    ;;
  esac
  if [ -f "$nikgapps_config_file_name" ]; then
    case "$install_partition_val" in
      "default") addToLog "- InstallPartition is default" ;;
      "system") install_partition=$system ;;
      "product") install_partition=$product ;;
      "system_ext") install_partition=$system_ext ;;
      "data") install_partition="/data/extra" ;;
      /*) install_partition=$install_partition_val ;;
    esac
    addToLog "- InstallPartition = $install_partition"
  else
    addToLog "- nikgapps.config file doesn't exist!"
  fi
  case "$install_partition" in
    *"/product") product_prefix="product/" ;;
    *"/system_ext") product_prefix="system_ext/" ;;
    *) product_prefix="" ;;
  esac
}

make_dir() {
  addToLog "- Creating Directory: $install_partition/$1"
  mkdir -p "$install_partition/$1"
  set_perm 1000 1000 0755 "$install_partition/$1"
}

# Initialize the variables
default_partition="product"
clean_flash_only="false"
find_Install_partition
title="GoogleDialer"
package_title="GoogleDialer"
pkg_size="57233"
package_name="com.google.android.dialer"
packagePath=installGoogleDialerFiles
deleteFilesPath=deleteGoogleDialerFiles
deleteFilesFromRomPath=deleteGoogleDialerFromRomFiles

remove_aosp_apps_from_rom="
Dialer
"

remove_gapps_from_rom="
"

file_list="
___priv-app___GoogleDialer/GoogleDialer.apk
___etc___permissions/com.google.android.dialer.xml
___overlay/GmsConfigOverlayComms.apk
___framework/com.google.android.dialer.support.jar
"

remove_existing_package() {
   # remove the existing folder for clean install of GoogleDialer
   delete_package "GoogleDialer"
}

remove_aosp_apps() {
   # Delete the folders that we want to remove with installing GoogleDialer
   for i in $remove_aosp_apps_from_rom; do
       RemoveAospAppsFromRom "$i"
   done
}

remove_gapps_from_rom() {
   # Delete the folders that we want to remove with installing on Rom with Gapps
   for i in $remove_gapps_from_rom; do
       RemoveFromRomWithGapps "$i"
   done
}

install_package() {
   remove_existing_package
   remove_aosp_apps
   remove_gapps_from_rom
   # Create folders and set the permissions
   make_dir "priv-app/GoogleDialer"
   make_dir "etc/permissions"
   make_dir "overlay"

   # Copy the files and set the permissions
   for i in $file_list; do
       install_file "$i"
   done
   install_file "___etc___permissions/GoogleDialer.prop"

script_text="<permissions>
                            <!-- Shared library required on the device to get Google Dialer updates from
                                 Play Store. This will be deprecated once Google Dialer play store
                                 updates stop supporting pre-O devices. -->
                            <library name=\"com.google.android.dialer.support\"
                              file=\"$install_partition/framework/com.google.android.dialer.support.jar\" />

                            <!-- Starting from Android O and above, this system feature is required for
                                 getting Google Dialer play store updates. -->
                            <feature name=\"com.google.android.apps.dialer.SUPPORTED\" />
                        </permissions>"
                        echo -e "$script_text" > $install_partition/etc/permissions/com.google.android.dialer.support.xml
                        set_perm 0 0 0644 "$install_partition/etc/permissions/com.google.android.dialer.support.xml"
                        installPath=$product_prefix"etc/permissions/com.google.android.dialer.support.xml"
                        echo "install=$installPath" >> $TMPDIR/addon/$packagePath
                        if [ -f "$install_partition/etc/permissions/com.google.android.dialer.support.xml" ]; then
                          addToLog "- $install_partition/etc/permissions/com.google.android.dialer.support.xml Successfully Written!"
                        fi

                         # set Google Dialer as default; based on the work of osm0sis @ xda-developers
                          setver="122"  # lowest version in MM, tagged at 6.0.0
                          setsec="/data/system/users/0/settings_secure.xml"
                          if [ -f "$setsec" ]; then
                            if grep -q 'dialer_default_application' "$setsec"; then
                              if ! grep -q 'dialer_default_application" value="com.google.android.dialer' "$setsec"; then
                                curentry="$(grep -o 'dialer_default_application" value=.*$' "$setsec")"
                                newentry='dialer_default_application" value="com.google.android.dialer" package="android" />\r'
                                sed -i "s;${curentry};${newentry};" "$setsec"
                              fi
                            else
                              max="0"
                              for i in $(grep -o 'id=.*$' "$setsec" | cut -d '"' -f 2); do
                                test "$i" -gt "$max" && max="$i"
                              done
                              entry='<setting id="'"$((max + 1))"'" name="dialer_default_application" value="com.google.android.dialer" package="android" />\r'
                              sed -i "/<settings version=\"/a\ \ ${entry}" "$setsec"
                            fi
                          else
                            if [ ! -d "/data/system/users/0" ]; then
                              install -d "/data/system/users/0"
                              chown -R 1000:1000 "/data/system"
                              chmod -R 775 "/data/system"
                              chmod 700 "/data/system/users/0"
                            fi
                            { echo -e "<?xml version='1.0' encoding='UTF-8' standalone='yes' ?>\r"
                            echo -e '<settings version="'$setver'">\r'
                            echo -e '  <setting id="1" name="dialer_default_application" value="com.google.android.dialer" package="android" />\r'
                            echo -e '</settings>'; } > "$setsec"
                          fi
                          chown 1000:1000 "$setsec"
                          chmod 600 "$setsec"

                          if [ -f "$setsec" ]; then
                            addToLog "- $setsec Successfully Written!"
                          fi
   chmod 755 "$COMMONDIR/addon";
   . $COMMONDIR/addon "$OFD" "GoogleDialer" "$TMPDIR/addon/$packagePath" "$TMPDIR/addon/$deleteFilesPath" "" "$TMPDIR/addon/$deleteFilesFromRomPath"
   copy_file "$NikGappsAddonDir/GoogleDialer.sh" "$logDir/addonscripts/GoogleDialer.sh"
   copy_file "$TMPDIR/addon/$packagePath" "$logDir/addonfiles/$packagePath.addon"
   rm -rf "$TMPDIR/addon/$packagePath"
   copy_file "$TMPDIR/addon/$deleteFilesPath" "$logDir/addonfiles/$deleteFilesPath.addon"
   copy_file "$TMPDIR/addon/$deleteFilesFromRomPath" "$logDir/addonfiles/$deleteFilesFromRomPath.addon"
   rm -rf "$TMPDIR/addon/$deleteFilesPath"
   rm -rf "$TMPDIR/addon/$deleteFilesFromRomPath"
}

uninstall_package() {
   # Remove the files when we're uninstalling NiKGapps
   for i in $file_list; do
       uninstall_file "$i"
   done
}

find_install_mode

