#!/sbin/sh
configValue="$1"
nikgapps_config_file_name="$2"

find_Install_partition() {
  addToLog "- default_partition=$default_partition"
  install_partition="/system/product"
  case $default_partition in
    "system_ext")
      [ -z "$system_ext" ] && system_ext=$product
      # if partition doesn't exist or it is not mounted as rw, moving to secondary partition
      [ -z "$system_ext" ] && system_ext=$system
      install_partition=$system_ext
    ;;
    "product")
      # if partition doesn't exist or it is not mounted as rw, moving to secondary partition
      [ -z "$product" ] && product=$system
      install_partition=$product
    ;;
  esac
  if [ -f "$nikgapps_config_file_name" ]; then
    case "$install_partition_val" in
      "default") addToLog "- InstallPartition is default" ;;
      "system") install_partition=$system ;;
      "product") install_partition=$product ;;
      "system_ext") install_partition=$system_ext ;;
      "data") install_partition="/data/extra" ;;
      /*) install_partition=$install_partition_val ;;
    esac
    addToLog "- InstallPartition = $install_partition"
  else
    addToLog "- nikgapps.config file doesn't exist!"
  fi
  case "$install_partition" in
    *"/product") product_prefix="product/" ;;
    *"/system_ext") product_prefix="system_ext/" ;;
    *) product_prefix="" ;;
  esac
}

make_dir() {
  addToLog "- Creating Directory: $install_partition/$1"
  mkdir -p "$install_partition/$1"
  set_perm 1000 1000 0755 "$install_partition/$1"
}

# Initialize the variables
default_partition="product"
clean_flash_only="false"
find_Install_partition
title="ExtraFiles"
package_title="ExtraFiles"
pkg_size="843"
package_name=""
packagePath=installExtraFilesFiles
deleteFilesPath=deleteExtraFilesFiles
deleteFilesFromRomPath=deleteExtraFilesFromRomFiles

remove_aosp_apps_from_rom="
"

remove_gapps_from_rom="
"

file_list="
___etc___preferred-apps/google.xml
___etc___default-permissions/nikgapps-permissions.xml
___etc___default-permissions/default-permissions.xml
___etc___default-permissions/default-permissions-google.xml
___etc___sysconfig/pixel_experience_2018.xml
___etc___sysconfig/pixel_experience_2019.xml
___etc___sysconfig/pixel_experience_2020.xml
___etc___sysconfig/google-staged-installer-whitelist.xml
___etc___sysconfig/dialer_experience.xml
___etc___sysconfig/wellbeing.xml
___etc___sysconfig/pixel_2016_exclusive.xml
___etc___sysconfig/preinstalled-packages-platform-handheld-product.xml
___etc___sysconfig/pixel.xml
___etc___sysconfig/pixel_experience_2020_midyear.xml
___etc___sysconfig/nexus.xml
___etc___sysconfig/nga.xml
___etc___sysconfig/backup.xml
___etc___sysconfig/google-rollback-package-whitelist.xml
___etc___sysconfig/pixel_experience_2019_midyear.xml
___etc___sysconfig/google_vr_build.xml
___etc___sysconfig/preinstalled-packages-platform-overlays.xml
___etc___sysconfig/pixel_2019_exclusive.xml
___etc___sysconfig/google-hiddenapi-package-whitelist.xml
___etc___sysconfig/pixel_experience_2017.xml
___etc___sysconfig/google_build.xml
___lib64/libgdx.so
___etc___permissions/privapp-permissions-google-product.xml
___etc___permissions/privapp-permissions-google-comms-suite.xml
___etc___permissions/NikGapps-privapp-permissions-google.xml
___etc___permissions/com.google.android.dialer.support.xml
___etc___permissions/privapp-permissions-google-system-ext.xml
___etc___permissions/split-permissions-google.xml
___etc___permissions/privapp-permissions-google-p.xml
___etc___permissions/privapp-permissions-hotword.xml
___overlay/GmsConfigOverlayCommon.apk
___overlay/GmsContactsProviderOverlay.apk
___overlay/GmsConfigOverlayGSA.apk
___framework/com.google.android.media.effects.jar
___framework/com.google.android.dialer.support.jar
___framework/com.google.widevine.software.drm.jar
___framework/com.google.android.maps.jar
"

remove_existing_package() {
   # remove the existing folder for clean install of ExtraFiles
   delete_package "ExtraFiles"
}

remove_aosp_apps() {
   # Delete the folders that we want to remove with installing ExtraFiles
   for i in $remove_aosp_apps_from_rom; do
       RemoveAospAppsFromRom "$i"
   done
}

remove_gapps_from_rom() {
   # Delete the folders that we want to remove with installing on Rom with Gapps
   for i in $remove_gapps_from_rom; do
       RemoveFromRomWithGapps "$i"
   done
}

install_package() {
   remove_existing_package
   remove_aosp_apps
   remove_gapps_from_rom
   # Create folders and set the permissions
   make_dir "etc/preferred-apps"
   make_dir "etc/default-permissions"
   make_dir "etc/sysconfig"
   make_dir "lib64"
   make_dir "etc/permissions"
   make_dir "overlay"

   # Copy the files and set the permissions
   for i in $file_list; do
       install_file "$i"
   done
   install_file "___etc___permissions/ExtraFiles.prop"

script_text="<permissions>
                    <!-- Shared library required on the device to get Google Dialer updates from
                         Play Store. This will be deprecated once Google Dialer play store
                         updates stop supporting pre-O devices. -->
                    <library name=\"com.google.android.dialer.support\"
                      file=\"$install_partition/framework/com.google.android.dialer.support.jar\" />

                    <!-- Starting from Android O and above, this system feature is required for
                         getting Google Dialer play store updates. -->
                    <feature name=\"com.google.android.apps.dialer.SUPPORTED\" />
                </permissions>"
                echo -e "$script_text" > $install_partition/etc/permissions/com.google.android.dialer.support.xml
                set_perm 0 0 0644 "$install_partition/etc/permissions/com.google.android.dialer.support.xml"
                installPath=$product_prefix"etc/permissions/com.google.android.dialer.support.xml"
                echo "install=$installPath" >> $TMPDIR/addon/$packagePath
                if [ -f "$install_partition/etc/permissions/com.google.android.dialer.support.xml" ]; then
                  addToLog "- $install_partition/etc/permissions/com.google.android.dialer.support.xml Successfully Written!"
                fi
                script_text="<permissions>
                    <library name=\"com.google.android.maps\"
                            file=\"$install_partition/framework/com.google.android.maps.jar\" />
                </permissions>"
                echo -e "$script_text" > $install_partition/etc/permissions/com.google.android.maps.xml
                set_perm 0 0 0644 "$install_partition/etc/permissions/com.google.android.maps.xml"
                installPath=$product_prefix"etc/permissions/com.google.android.maps.xml"
                echo "install=$installPath" >> $TMPDIR/addon/$packagePath
                if [ -f "$install_partition/etc/permissions/com.google.android.maps.xml" ]; then
                  addToLog "- $install_partition/etc/permissions/com.google.android.maps.xml Successfully Written!"
                fi
                        script_text="<permissions>
            <library name=\"com.google.widevine.software.drm\"
                file=\"/system/product/framework/com.google.widevine.software.drm.jar\"/>
        </permissions>"
                        echo -e "$script_text" > $install_partition/etc/permissions/com.google.widevine.software.drm.xml
                        set_perm 0 0 0644 "$install_partition/etc/permissions/com.google.widevine.software.drm.xml"
                        installPath=$product_prefix"etc/permissions/com.google.widevine.software.drm.xml"
                        echo "install=$installPath" >> $TMPDIR/addon/$packagePath
                        if [ -f "$install_partition/etc/permissions/com.google.widevine.software.drm.xml" ]; then
                          addToLog "- $install_partition/etc/permissions/com.google.widevine.software.drm.xml Successfully Written!"
                        fi
                        script_text="<permissions>
            <library name=\"com.google.android.media.effects\"
                    file=\"$install_partition/framework/com.google.android.media.effects.jar\" />

        </permissions>"
                        echo -e "$script_text" > $install_partition/etc/permissions/com.google.android.media.effects.xml
                        set_perm 0 0 0644 "$install_partition/etc/permissions/com.google.android.media.effects.xml"
                        installPath=$product_prefix"etc/permissions/com.google.android.media.effects.xml"
                        echo "install=$installPath" >> $TMPDIR/addon/$packagePath
                        if [ -f "$install_partition/etc/permissions/com.google.android.media.effects.xml" ]; then
                          addToLog "- $install_partition/etc/permissions/com.google.android.media.effects.xml Successfully Written!"
                        fi
   chmod 755 "$COMMONDIR/addon";
   . $COMMONDIR/addon "$OFD" "ExtraFiles" "$TMPDIR/addon/$packagePath" "$TMPDIR/addon/$deleteFilesPath" "" "$TMPDIR/addon/$deleteFilesFromRomPath"
   copy_file "$NikGappsAddonDir/ExtraFiles.sh" "$logDir/addonscripts/ExtraFiles.sh"
   copy_file "$TMPDIR/addon/$packagePath" "$logDir/addonfiles/$packagePath.addon"
   rm -rf "$TMPDIR/addon/$packagePath"
   copy_file "$TMPDIR/addon/$deleteFilesPath" "$logDir/addonfiles/$deleteFilesPath.addon"
   copy_file "$TMPDIR/addon/$deleteFilesFromRomPath" "$logDir/addonfiles/$deleteFilesFromRomPath.addon"
   rm -rf "$TMPDIR/addon/$deleteFilesPath"
   rm -rf "$TMPDIR/addon/$deleteFilesFromRomPath"
}

uninstall_package() {
   # Remove the files when we're uninstalling NiKGapps
   for i in $file_list; do
       uninstall_file "$i"
   done
}

find_install_mode

